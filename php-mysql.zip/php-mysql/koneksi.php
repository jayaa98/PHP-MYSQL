<?php
// Informasi koneksi ke database
$host = "localhost"; // Ganti dengan nama host MySQL Anda
$username = "root"; // Ganti dengan nama pengguna MySQL Anda
$password = ""; // Ganti dengan kata sandi MySQL Anda
$database = "db_adi"; // Ganti dengan nama database Anda

// Membuat koneksi ke database
$koneksi = mysqli_connect($host, $username, $password, $database);

// Memeriksa apakah koneksi berhasil
if (!$koneksi) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}

// Set karakter set untuk koneksi (opsional)
mysqli_set_charset($koneksi, "utf8");

// Jika Anda ingin menggunakan koneksi ini di berbagai bagian skrip PHP,
// Anda bisa menyertakan file ini di berbagai skrip dengan pernyataan `include`.

// Contoh penggunaan koneksi:
// mysqli_query($koneksi, "SELECT * FROM tabel_nama");

?>
